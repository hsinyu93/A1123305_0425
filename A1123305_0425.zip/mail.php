<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;

    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $name=$_POST["name"];
    $email=$_POST["email"];
    $photo=$_POST["photo"];

    echo "Name: ".$name."<br>";
    echo "Email: ".$email."<br>";
    echo "Photo(圖片網址): ".$photo."<br>";
    echo "<img src='$photo' alt='photo' style='width:50%'><br>";

    $link=mysqli_connect(
        'localhost',
        'root',
        '',
        'A1123305_0425HW'
    );

    mysqli_set_charset($link, "utf8");

    $sql="INSERT INTO user(Name, Email, Photo) VALUES('$name', '$email', '$photo')";

    if(mysqli_query($link, $sql)){

        //Create an instance; passing `true` enables exceptions
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'a1123305@mail.nuk.edu.tw';                     //SMTP username
            $mail->Password   = 'xswj xufc ehoq gilb';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            $mail->CharSet = "utf-8";

            //Recipients
            $mail->setFrom('a1123305@mail.nuk.edu.tw', 'Mailer');
            //$mail->addAddress('joe@example.net', 'Joe User');     //Add a recipient               //Name is optional
            $mail->addAddress($email);
            //$mail->addReplyTo('info@example.com', 'Information');
            //$mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');
    
            //Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
    
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->CharSet = "UTF-8";
            $mail->Subject = "恭喜註冊成功";
            $mail->Body    = 
            "恭喜註冊成功<br>
            Name: ".$name."<br>
            Photo: <br>
            <img src='$photo' alt='photo' style='width:70%'><br>";
            //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }else{
        echo "註冊失敗";
        header("Refresh:3;url='uPload.php'");
    }
?>