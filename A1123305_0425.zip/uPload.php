<form action="mail.php" method="post">
    Name:<input type="text" name="name"><br>
    Email:<input type="email" name="email"><br>
    Photo(圖片網址):<input type="text" name="photo"><br>
    <input type="submit" value="Register">
</form>
