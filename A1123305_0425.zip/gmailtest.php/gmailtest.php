<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$mail = new PHPMailer(true);

    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'ihsien.ting@gmail.com';                     //SMTP username
    $mail->Password   = 'ttyl iqhs uuvd xxnx';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    $mail->CharSet = "utf-8";

    $mail->setFrom('iting@nuk.edu.tw', 'Mailer');
    $mail->addAddress('ihsien.ting@gmail.com', 'Joe User');     //Add a recipient
    $mail->addAddress('ihsien.ting@outlook.com');               //Name is optional
    $mail->addReplyTo('iting@nuk.edu.tw', 'Information');
    $mail->addCC('iting@nuk.edu.tw');
    $mail->addBCC('iting@nuk.edu.tw');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);
    $mail->Subject = '我是測試信';
    $mail->Body    = '測試社This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();

?>